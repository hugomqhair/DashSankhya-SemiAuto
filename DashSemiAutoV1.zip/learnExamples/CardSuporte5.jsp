<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored="false" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html>
<head>
    <link href="${BASE_FOLDER}/css/style.css" rel="stylesheet">
    <style>
        .kpi-card {
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            background: #ffffff;
            border-left: 5px solid #cccccc;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            transition: all 0.2s ease;
        }
        .kpi-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .status-label {
            font-size: 11px;
            color: #777;
            margin-bottom: 2px;
        }
        .status-valor {
            font-size: 26px;
            font-weight: bold;
            line-height: 1;
        }
    </style>
</head>
<body class="bg-gray-100 p-1">

    <!-- KPIs de status no topo -->
    <div class="grid grid-cols-4 gap-2 mb-2">
        <div id="kpi-analise" class="kpi-card cursor-pointer" onclick="filtrarPorStatus('ANALISE')">
            <div class="status-label">Em Análise</div>
            <div id="valor-analise" class="status-valor">–</div>
        </div>
        <div id="kpi-dev" class="kpi-card cursor-pointer" onclick="filtrarPorStatus('DEV')">
            <div class="status-label">Em Dev</div>
            <div id="valor-dev" class="status-valor">–</div>
        </div>
        <div id="kpi-aguarda" class="kpi-card cursor-pointer" onclick="filtrarPorStatus('AGUARDA')">
            <div class="status-label">Aguarda Usuário</div>
            <div id="valor-aguarda" class="status-valor">–</div>
        </div>
<%--         <div id="kpi-outros" class="kpi-card cursor-pointer" onclick="filtrarPorStatus('OUTROS')">
            <div class="status-label">Outros</div>
            <div id="valor-outros" class="status-valor">–</div>
        </div> --%>
        <div id="kpi-concluidos" class="kpi-card cursor-pointer" onclick="filtrarPorStatus('CONCLUIDOS')">
            <div class="status-label">Concluídos Mes</div>
            <div id="valor-concluidos" class="status-valor">–</div>
        </div>
    </div>

    <!-- Tabela Principal -->
    <div class="max-w-7xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
        <table class="w-full table-auto">
            <thead class="bg-gradient-to-r from-green-600 to-green-700 text-white">
                <tr id="thead"></tr>
            </thead>
            <tbody id="tbody" class="divide-y divide-gray-200"></tbody>
        </table>
    </div>

</body>
<snk:load/>
<script>globalThis.url = '${BASE_FOLDER}';</script>
<script src="${BASE_FOLDER}/js/query2.js"></script>
<script src="${BASE_FOLDER}/plugin/tailwind.js"></script>
<script>

function decodeHtmlEntities(str) {
    var txt = document.createElement("textarea");
    txt.innerHTML = str;
    return txt.value;
}

// ============= CONFIGURAÇÃO DO DASH =============
const CONFIG = {
    queryPrincipal: query(),
    queryDetalhe: function(param) { return query2(param); },
    abrirApp: function(key) { openApp("br.com.sankhya.menu.adicional.AD_SUPORTE", { ID: key }); },
    queryCountAnalise: queryCountAnalise(),
    queryCountDev: queryCountDev(),
    queryCountAguarda: queryCountAguarda(),
    queryCountOutros: queryCountOutros(),
    queryCountConcluidos: queryCountConcluidos()
};
// ================================================

// Variável de controle do filtro atual
let filtroAtual = null;   // null = mostra todos

function atualizarKPIsDinamicos() {
    var kpis = [
        { id: 'analise',    query: CONFIG.queryCountAnalise,    valorId: 'valor-analise',    cardId: 'kpi-analise' },
        { id: 'dev',        query: CONFIG.queryCountDev,        valorId: 'valor-dev',        cardId: 'kpi-dev' },
        { id: 'aguarda',    query: CONFIG.queryCountAguarda,    valorId: 'valor-aguarda',    cardId: 'kpi-aguarda' },
        { id: 'outros',     query: CONFIG.queryCountOutros,     valorId: 'valor-outros',     cardId: 'kpi-outros' },
        { id: 'concluidos', query: CONFIG.queryCountConcluidos, valorId: 'valor-concluidos', cardId: 'kpi-concluidos' }
    ];

    kpis.forEach(function(kpi) {
        executeQuery(kpi.query, [], function(result) {
            try {
                var dados = JSON.parse(result);
                if (dados && dados.length > 0) {
                    var row = dados[0];
                    var qtd = row.QTD || 0;
                    var cor = row.COR || '#cccccc';

                    document.getElementById(kpi.valorId).textContent = qtd;

                    var card = document.getElementById(kpi.cardId);
                    card.style.borderLeftColor = cor;
                    var valorEl = document.getElementById(kpi.valorId);
                    valorEl.style.color = cor;

                    var corSuave = cor + '15';
                    card.style.background = 'linear-gradient(to right, ' + corSuave + ', #ffffff)';
                }
            } catch (e) {
                console.error('Erro ao processar KPI ' + kpi.id, e);
            }
        });
    });
}

// ==================== FILTRO POR KPI ====================
function filtrarPorStatus(tipo) {
    
    // Se clicar no mesmo KPI novamente → limpa o filtro (mostra todos)
    if (filtroAtual === tipo) {
        filtroAtual = null;
        limparHighlightKPIs();
        carregarTabela(CONFIG.queryPrincipal);
        return;
    }

    filtroAtual = tipo;
    limparHighlightKPIs();

    // Destaca o KPI clicado
    var card = document.getElementById('kpi-' + tipo);
    if (card) {
        card.style.boxShadow = '0 0 0 3px rgba(0,0,0,0.2)';
        card.style.borderLeftWidth = '6px';
    }

    // Define qual query usar
    var queryFiltrada;

    switch(tipo) {
        case 'ANALISE':
            queryFiltrada = CONFIG.queryCountAnalise.replace('COUNT(1) QTD', 'id AS KEY, ...') ; // não é bom
            // Melhor abordagem: crie queries específicas de filtro no query2.js
            queryFiltrada = queryFiltradaAnalise();   // vamos criar no query2.js
            break;
        case 'DEV':
            queryFiltrada = queryFiltradaDev();
            break;
        case 'AGUARDA':
            queryFiltrada = queryFiltradaAguarda();
            break;
        case 'CONCLUIDOS':
            queryFiltrada = queryFiltradaConcluidos();
            break;
        default:
            queryFiltrada = CONFIG.queryPrincipal;
    }

    carregarTabela(queryFiltrada);
}

// Função centralizada para carregar a tabela
function carregarTabela(queryString) {
    executeQuery(queryString, [], function(result) {
        var dados = JSON.parse(result);
        console.log('Tabela carregada com filtro:', filtroAtual, ' - Registros:', dados.length);
        
        montarCabecalho(dados);
        tbody.innerHTML = dados.map(function(item, i) {
            return montarLinha(item, i);
        }).join('');
    }, function(err) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-red-600 py-8">Erro ao carregar tabela</td></tr>';
        console.error(err);
    });
}

// Remove highlight de todos os KPIs
function limparHighlightKPIs() {
    var cards = document.querySelectorAll('.kpi-card');
    cards.forEach(function(card) {
        card.style.boxShadow = '';
        card.style.borderLeftWidth = '5px';
    });
}

var tbody = document.getElementById('tbody');
var thead = document.getElementById('thead');

function montarCabecalho(dados) {
    if (!dados || dados.length === 0) return;

    var colunasVisiveis = Object.keys(dados[0]).filter(function(k) {
        return k !== 'KEY' &&
               k !== 'COD_STATUS' &&
               k !== 'COR_STATUS' &&
               k !== 'ALERTA';
    });

    var cabecalhoHtml = '<th class="px-3 py-2 text-left text-xs font-bold uppercase tracking-wider">#</th>';

    colunasVisiveis.forEach(function(col) {
        cabecalhoHtml += '<th class="px-3 py-2 text-left text-xs font-bold uppercase tracking-wider">' + col.replace('_','') + '</th>';
    });

    thead.innerHTML = cabecalhoHtml;
}

function montarLinha(item, index) {
    console.log('montarLinha - item completo:', item);

    var colunas = Object.keys(item).filter(function(k) { return k !== 'KEY'; });
    var key = item.KEY || index;
    var celulas = '';

    // Coluna de status visual (#)
    var cor = item.COR_STATUS || '#7F8C8D';
    var alerta = item.ALERTA ? decodeHtmlEntities(item.ALERTA) : '';

    var htmlStatus = 
        '<span style="display: inline-flex; align-items: center; gap: 6px; font-size: 11px;">' +
            '<span style="width: 10px; height: 10px; border-radius: 50%; background-color: ' + cor + '; display: inline-block; flex-shrink: 0; box-shadow: 0 0 0 1px rgba(255,255,255,0.6);"></span>' +
            (alerta ? '<span style="font-size: 12px;">' + alerta + '</span>' : '') +
        '</span>';

    celulas += '<td class="px-2 py-1 text-center">' + htmlStatus + '</td>';

    // Demais colunas
    colunas.forEach(function(col) {
        if (['COR_STATUS', 'ALERTA', 'COD_STATUS'].indexOf(col) !== -1) return;

        var aligning = (col.slice(-1) === '_') ? 'text-right pr-2' : '';
        var valor = (item[col] != null) ? item[col] : '';

        celulas += '<td class="px-2 py-1 text-[11px] ' + aligning + '">' + valor + '</td>';
    });

    // Linha + detalhe
    var html = 
        '<tr class="bg-white hover:bg-gray-50 cursor-pointer transition-all" onclick="toggleDetalhe(\'' + key + '\', this)">' +
            celulas +
        '</tr>' +
        '<tr id="detail-' + key + '" class="hidden bg-gray-50 border-t-4 border-green-500">' +
            '<td colspan="' + colunas.length + '" class="p-1">' +
                '<div class="text-center py-3">Carregando detalhes...</div>' +
            '</td>' +
        '</tr>';

    return html;
}

// Abre/fecha detalhe + carrega sub-tabela
function toggleDetalhe(key, linhaClicada) {
    //console.log('key, linhaClicada', key, linhaClicada)
    const detailRow = document.getElementById('detail-' + key);
    
    // Se já está aberto → fecha
    if (!detailRow.classList.contains('hidden')) {
        detailRow.classList.add('hidden');
        return;
    }

    // Abre a linha de detalhe
    detailRow.classList.remove('hidden');

    // Busca os dados do detalhe
    const qryDetalhe = CONFIG.queryDetalhe(key); // aqui você passa o parâmetro que precisar (ex: data, NUFIN, etc)
    //console.log('qryDetalhe',qryDetalhe)
    executeQuery(qryDetalhe, [], (result) => {
        const dados =  JSON.parse(result);
        detailRow.querySelector('td').innerHTML = gerarSubTabela(dados);
    }, (err) => {
        detailRow.querySelector('td').innerHTML = `<div class="text-red-600">Erro ao carregar detalhes</div>`;
    });
}

// Gera sub-tabela (mesmo estilo da principal, mas menor)
function gerarSubTabela(dados) {
    // Caso não tenha dados
    if (!dados || dados.length === 0) {
        return '<div class="text-center text-gray-500 py-1">Nenhum detalhe encontrado</div>';
    }

    var colunas = Object.keys(dados[0]).filter(function(k) { return k !== 'KEY'; });
    var html = '';

    // Início da tabela
    html += '<div class="overflow-x-auto">';
    html += '<table class="w-full table-auto border border-gray-300">';
    
    // Cabeçalho
    html += '<thead class="bg-gray-700 text-white p-0">';
    html += '<tr>';
    for (var i = 0; i < colunas.length; i++) {
        html += '<th class="px-1 py-0 text-left text-[8px] font-bold">' + colunas[i] + '</th>';
    }
    html += '</tr></thead>';

    // Corpo da tabela
    html += '<tbody class="bg-white divide-y divide-gray-300">';

    for (var i = 0; i < dados.length; i++) {
        var item = dados[i];
        var temKey = item.KEY ? true : false;
        var classeCursor = temKey ? ' cursor-pointer' : '';
        var onclick = temKey ? ' onclick="CONFIG.abrirApp(\'' + item.KEY + '\')"' : '';

        html += '<tr class="hover:bg-gray-100' + classeCursor + '"' + onclick + '>';

        for (var j = 0; j < colunas.length; j++) {
            var valor = (item[colunas[j]] != null) ? item[colunas[j]] : '';
            html += '<td class="px-1 py-1 text-[9px]">' + valor + '</td>';
        }

        html += '</tr>';
    }

    // Fechamento da tabela
    html += '</tbody></table></div>';

    return html;
}

// As funções toggleDetalhe e gerarSubTabela permanecem iguais (já sem backticks problemáticos)

executeQuery(CONFIG.queryPrincipal, [], function (result) {
    var dados = JSON.parse(result);
    console.log('dados', dados);
    montarCabecalho(dados);
    tbody.innerHTML = dados.map(function(item, i) { return montarLinha(item, i); }).join('');
    atualizarKPIsDinamicos();
}, function (err) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-red-600 py-8">Erro na consulta principal</td></tr>';
});
</script>
</html>