#!/bin/bash

echo ""
echo ""
echo "   Compactando pasta Buscar Notas..."
echo ""
echo ""

# Caminho do arquivo zip de saída
DESTINO="$HOME/Downloads/DashSemiAutoV1.zip"

# Compacta tudo ignorando a pasta BKP
zip -r "$DESTINO" . -x "*/BKP/*"
