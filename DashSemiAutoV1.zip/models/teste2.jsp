<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8"  isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html>
	<head> 
		<snk:load/>

			<script>
				function conso2(){
					console.log("---------- BUSCANDO NUGDG ----------");

						// 1. Pegamos a string de parâmetros da URL atual (?entryPoint=teste.jsp&nuGdg=320...)
						const queryParams = new URLSearchParams(window.location.search);

						// 2. Pegamos especificamente o valor do nuGdg
						const var_nuGdg = queryParams.get("nuGdg");

						if (nuGdg) {
							console.log("Sucesso! O valor de nuGdg é:", nuGdg);
						} else {
							console.log("O parâmetro nuGdg não foi encontrado na URL atual.");
							console.log("URL detectada:", window.location.href);
						}
				}  
			</script> 
			<style>
				.tabelaParceiros {
					height: 70%;
					width: 100%;
					overflow:scroll;
				}

				.tabelaContatos {
					height: 30%;
					width: 100%;
					overflow:scroll;
				}

			</style>		
			
	</head>
	<body>
		<h1>Testando variaveis de ambiente</h1>
		<button onclick="conso2()"> Console </button>
	</body>
</html>
