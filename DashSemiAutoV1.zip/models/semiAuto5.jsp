<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored="false" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html>
<head>
    <link href="${BASE_FOLDER}/css/style.css" rel="stylesheet">
    <style>
        .kpi-card {
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            background: #ffffff;
            border-left: 5px solid #cccccc;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .kpi-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .kpi-card.active {
            box-shadow: 0 0 0 3px rgba(0,0,0,0.18), 0 4px 8px rgba(0,0,0,0.1);
            border-left-width: 6px;
        }
        .status-label {
            font-size: 11px;
            color: #777;
            margin-bottom: 2px;
        }
        .status-valor {
            font-size: 24px;
            font-weight: bold;
            line-height: 1;
        }
    </style>
</head>

<body class="bg-gray-100 p-1">
    <div id="kpi-container" class="grid grid-flow-col grid-rows-1 gap-1 mb-2"></div>

    <div class="max-w-full bg-white rounded-xl shadow-lg overflow-hidden">
        <table class="w-full table-auto">
            <thead class="bg-gradient-to-r from-green-600 to-green-700 text-white">
                <tr id="thead"></tr>
            </thead>
            <tbody id="tbody" class="divide-y divide-gray-200"></tbody>
        </table>
    </div>
</body>

<snk:load/>
<script src="${BASE_FOLDER}/plugin/tailwind.js"></script>
<script>
    const SQL_CONFIG = "SELECT query AS QUERYPRINCIPAL, querydet AS QUERYDETALHE FROM AD_CARDGDG WHERE NUGDG = ?";

    const CONFIG = {
        queryPrincipal: null,
        queryDetalhe: null,
        abrirApp: function(key) {
            openApp("br.com.sankhya.fin.cad.movimentacaoFinanceira", { NUFIN: key });
        }
    };

    const HIDDEN_COLS = ["KEY", "KPI_COLOR", "KPI_MEDIDA", "KPI_TITULO"];
    let fullData = [];
    let filtroAtual = null;

    var kpiContainer = document.getElementById("kpi-container");
    var thead = document.getElementById("thead");
    var tbody = document.getElementById("tbody");

    function showError(msg) {
        thead.innerHTML = "";
        tbody.innerHTML = "<tr><td class='text-center text-red-600 py-8'>" + msg + "</td></tr>";
    }

    function getFieldCaseInsensitive(row, options) {
        for (var i = 0; i < options.length; i++) {
            if (row[options[i]] != null && row[options[i]] !== "") {
                return row[options[i]];
            }
        }
        return null;
    }

    function sanitizeSql(sql) {
        var raw = String(sql || "");
        var txt = document.createElement("textarea");
        txt.innerHTML = raw;
        return txt.value
            .replace(/[\r\n]+/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function normalizeColor(value) {
        var c = String(value || "").trim();
        return c || "#64748b";
    }

    function normalizeTitle(value) {
        var t = String(value || "").trim();
        return t || "SEM TITULO";
    }

    function parseMeasure(value) {
        var n = Number(value);
        return isNaN(n) ? 0 : n;
    }

    function roundTo2(value) {
        return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
    }

    function formatMeasure(value) {
        return roundTo2(value).toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function calcularKPIs(dados) {
        var map = new Map();

        dados.forEach(function(item) {
            var titulo = normalizeTitle(item.KPI_TITULO);
            var cor = normalizeColor(item.KPI_COLOR);
            var medida = parseMeasure(item.KPI_MEDIDA != null ? item.KPI_MEDIDA : 1);
            var chave = titulo + "||" + cor;

            if (!map.has(chave)) {
                map.set(chave, { titulo: titulo, cor: cor, medida: 0 });
            }

            var kpi = map.get(chave);
            kpi.medida = roundTo2(kpi.medida + medida);
        });

        return Array.from(map.values());
    }

    function limparKPIs() {
        while (kpiContainer.firstChild) {
            kpiContainer.removeChild(kpiContainer.firstChild);
        }
    }

    function renderKPIs() {
        limparKPIs();
        var lista = calcularKPIs(fullData);

        lista.forEach(function(kpi) {
            var card = document.createElement("div");
            card.className = "kpi-card";
            if (filtroAtual && filtroAtual.titulo === kpi.titulo && filtroAtual.cor === kpi.cor) {
                card.classList.add("active");
            }

            card.style.borderLeftColor = kpi.cor;
            card.style.background = "linear-gradient(to right, " + kpi.cor + "15, #ffffff)";
            card.innerHTML = "<div class='status-label'>" + kpi.titulo + "</div><div class='status-valor' style='color:" + kpi.cor + "'>" + formatMeasure(kpi.medida) + "</div>";
            card.onclick = function() {
                if (filtroAtual && filtroAtual.titulo === kpi.titulo && filtroAtual.cor === kpi.cor) {
                    filtroAtual = null;
                } else {
                    filtroAtual = { titulo: kpi.titulo, cor: kpi.cor };
                }
                renderKPIs();
                renderTabela();
            };
            kpiContainer.appendChild(card);
        });

        var todos = document.createElement("div");
        todos.className = "kpi-card";
        if (!filtroAtual) {
            todos.classList.add("active");
        }
        todos.style.borderLeftColor = "#64748b";
        todos.style.background = "linear-gradient(to right, #64748b15, #ffffff)";
        todos.innerHTML = "<div class='status-label'>Todos</div><div class='status-valor' style='color:#64748b'>" + fullData.length + "</div>";
        todos.onclick = function() {
            filtroAtual = null;
            renderKPIs();
            renderTabela();
        };
        kpiContainer.appendChild(todos);
    }

    function dadosFiltrados() {
        if (!filtroAtual) {
            return fullData.slice();
        }
        return fullData.filter(function(item) {
            return normalizeTitle(item.KPI_TITULO) === filtroAtual.titulo &&
                   normalizeColor(item.KPI_COLOR) === filtroAtual.cor;
        });
    }

    function montarCabecalho(dados) {
        if (!dados || dados.length === 0) {
            thead.innerHTML = "";
            return [];
        }

        var colunas = Object.keys(dados[0]).filter(function(col) {
            return HIDDEN_COLS.indexOf(col) === -1;
        });

        var statusHeader = "<th class='px-3 py-2 text-left text-xs font-bold uppercase tracking-wider'>#</th>";
        var colsHeader = colunas.map(function(col) {
            return "<th class='px-3 py-2 text-left text-xs font-bold uppercase tracking-wider'>" + col + "</th>";
        }).join("");
        thead.innerHTML = statusHeader + colsHeader;
        return colunas;
    }

    function carregarDetalhe(detailCell, key) {
        var params = [{ value: key, type: "I" }];

        executeQuery(CONFIG.queryDetalhe, params, function(result) {
            var dados = JSON.parse(result) || [];
            detailCell.innerHTML = gerarSubTabela(dados);
        }, function(err) {
            detailCell.innerHTML = "<div class='text-red-600 py-2'>Erro ao carregar detalhes: " + err + "</div>";
        });
    }

    function renderTabela() {
        tbody.innerHTML = "";
        var dados = dadosFiltrados();

        if (!dados.length) {
            thead.innerHTML = "";
            tbody.innerHTML = "<tr><td class='text-center text-gray-500 py-8'>Nenhum registro encontrado</td></tr>";
            return;
        }

        var colunas = montarCabecalho(dados);

        dados.forEach(function(item) {
            var row = document.createElement("tr");
            row.className = "bg-white hover:bg-gray-50 cursor-pointer";

            var cor = normalizeColor(item.KPI_COLOR);
            var tdStatus = document.createElement("td");
            tdStatus.className = "px-2 py-2 text-center";
            tdStatus.innerHTML = "<span style=\"width: 10px; height: 10px; border-radius: 50%; background-color: " + cor + "; display: inline-block; flex-shrink: 0; box-shadow: 0 0 0 1px rgba(255,255,255,0.6);\"></span>";
            row.appendChild(tdStatus);

            colunas.forEach(function(col) {
                var td = document.createElement("td");
                td.className = "px-3 py-2 text-[11px]";
                if (col.slice(-1) === "_") {
                    td.className += " text-right pr-3";
                }
                td.textContent = item[col] != null ? item[col] : "";
                row.appendChild(td);
            });

            var detailRow = document.createElement("tr");
            detailRow.className = "hidden bg-gray-50";
            var detailCell = document.createElement("td");
            detailCell.colSpan = colunas.length + 1;
            detailCell.className = "p-2";
            detailCell.innerHTML = "<div class='text-center py-3 text-gray-500'>Carregando detalhes...</div>";
            detailRow.appendChild(detailCell);

            row.onclick = function() {
                if (detailRow.classList.contains("hidden")) {
                    detailRow.classList.remove("hidden");
                    carregarDetalhe(detailCell, item.KEY);
                } else {
                    detailRow.classList.add("hidden");
                }
            };

            tbody.appendChild(row);
            tbody.appendChild(detailRow);
        });
    }

    function gerarSubTabela(dados) {
        if (!dados || !dados.length) {
            return "<div class='text-center text-gray-500 py-1'>Nenhum detalhe encontrado</div>";
        }

        var colunas = Object.keys(dados[0]).filter(function(k) { return k !== "KEY"; });
        var html = "<div class='overflow-x-auto'><table class='w-full table-auto border border-gray-300'>";

        html += "<thead class='bg-gray-700 text-white'><tr>";
        colunas.forEach(function(col) {
            html += "<th class='px-1 py-1 text-left text-[10px] font-bold'>" + col + "</th>";
        });
        html += "</tr></thead><tbody class='bg-white divide-y divide-gray-300'>";

        dados.forEach(function(item) {
            var temKey = !!item.KEY;
            var onclick = temKey ? " onclick=\"CONFIG.abrirApp('" + item.KEY + "')\"" : "";
            var classes = temKey ? "cursor-pointer hover:bg-gray-100" : "";

            html += "<tr class='" + classes + "'" + onclick + ">";
            colunas.forEach(function(col) {
                var valor = item[col] != null ? item[col] : "";
                html += "<td class='px-2 py-1 text-[10px]'>" + valor + "</td>";
            });
            html += "</tr>";
        });

        html += "</tbody></table></div>";
        return html;
    }

    function carregarConfiguracaoEIniciar() {
        const queryParams = new URLSearchParams(window.location.search);
        const var_nuGdg = queryParams.get("nuGdg");

        if (!var_nuGdg) {
            showError("Parâmetro nuGdg não encontrado na URL.");
            return;
        }

        executeQuery(SQL_CONFIG, [{ value: var_nuGdg, type: "I" }], function(result) {
            var configRows = JSON.parse(result) || [];

            console.log('qurys', configRows)
            if (!configRows.length) {
                showError("Nenhuma configuração encontrada na AD_CARDGDG para nuGdg=" + var_nuGdg + ".");
                return;
            }

            var row = configRows[0];
            CONFIG.queryPrincipal = sanitizeSql(getFieldCaseInsensitive(row, ["QUERYPRINCIPAL", "queryprincipal", "QUERYPRINCIAPL", "queryprinciapl"]));
            CONFIG.queryDetalhe = sanitizeSql(getFieldCaseInsensitive(row, ["QUERYDETALHE", "querydetalhe", "QUERYDET", "querydet"]));

            if (!CONFIG.queryPrincipal) {
                showError("Campo QUERYPRINCIPAL não encontrado/sem valor na AD_CARDGDG.");
                return;
            }
            if (!CONFIG.queryDetalhe) {
                showError("Campo QUERYDETALHE não encontrado/sem valor na AD_CARDGDG.");
                return;
            }

            executeQuery(CONFIG.queryPrincipal, [], function(mainResult) {
                fullData = JSON.parse(mainResult) || [];
                renderKPIs();
                renderTabela();
            }, function(err) {
                showError("Erro ao executar QUERYPRINCIPAL: " + err);
            });
        }, function(err) {
            showError("Erro ao buscar configuração na AD_CARDGDG: " + err);
        });
    }

    carregarConfiguracaoEIniciar();
</script>
</html>
