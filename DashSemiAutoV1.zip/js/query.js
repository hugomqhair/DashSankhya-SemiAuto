function queryPrincipal() {
    return `--Statusnfe<>A ou SEM Confirmaçao
SELECT 
--CASE WHEN statusnfe IS NULL AND NUMNOTA=0 THEN 'NOTA NAO CONFIRMADA' ELSE FMQ_GET_CAMPOLISTA('STATUSNFE', 'TGFCAB', statusnfe) END KPI_TITULO,
    'NOTA PENDENTE' KPI_TITULO,
    '#ff0000' KPI_COLOR,
    1 AS KPI_MEDIDA,
    NUNOTA key,
    TO_CHAR(DTENTSAI,'DD/MM/YY') AS DTENTSAI,
    FMQ_GET_CAMPOLISTA('TIPMOV', 'TGFCAB', cab.tipmov) TIPMOV,
    CASE WHEN statusnfe IS NULL AND NUMNOTA=0 THEN 'NOTA NAO CONFIRMADA' ELSE FMQ_GET_CAMPOLISTA('STATUSNFE', 'TGFCAB', statusnfe) END STATUS
FROM tgfcab cab
LEFT JOIN tgftop top ON (cab.codtipoper= top.codtipoper AND cab.dhtipoper = top.dhalter)
WHERE (top.CODMODDOC = 55 AND CAB.TIPMOV NOT IN ('Z')) AND (cab.statusnfe<>'A' and cab.statusnfe not in ('D') OR cab.NUMNOTA=0) 
AND cab.dtentsai>='01/07/2025'

UNION ALL
--Pedido com erro de Endereço
SELECT 
    'ERRO no Endereco' KPI_TITULO,
    '#F54927'  KPI_COLOR,
    1 AS KPI_MEDIDA,
    NUNOTA key,
    TO_CHAR(DTENTSAI,'DD/MM/YY') AS DTENTSAI,
    FMQ_GET_CAMPOLISTA('TIPMOV', 'TGFCAB', cab.tipmov) TIPMOV,
    (SELECT OBSERVACAO FROM tsilib WHERE evento=1032 and NUCHAVE=CAB.NUNOTA) STATUS
FROM tgfcab cab WHERE nunota IN (
SELECT nuchave FROM tsilib WHERE evento=1032 AND dhlib IS NULL
)

UNION ALL
--Atend Direto Pendente
SELECT 
    'Atend Direto Pendente' KPI_TITULO,
    '#8f3985' KPI_COLOR,
    1 AS KPI_MEDIDA,
    NUNOTA key,
    TO_CHAR(DTENTSAI,'DD/MM/YY') AS DTENTSAI,
   FMQ_GET_CAMPOLISTA('TIPMOV', 'TGFCAB', cab.tipmov) TIPMOV,
   'PEND '||CODEMP||'-'||(SELECT REPLACE(RAZAOABREV,' ','') FROM TSIEMP WHERE CODEMP=CAB.CODEMP)||'---+'||(SELECT REPLACE(RAZAOABREV,' ','') FROM TSIEMP WHERE CODEMP<500 AND CGC=(SELECT cgc_cpf FROM TGFPAR WHERE codparc=cab.codparc)) STATUS
FROM tgfcab cab 
WHERE tipmov='V' AND codparc IN (SELECT codparc FROM tgfpar WHERE cgc_cpf IN ((SELECT cgc FROM tsiemp)))
AND DTNEG>='01/07/2025'
AND CODEMP<>CODPARC
AND CODEMP NOT IN (9) --R. Nobrega pediu pra retirar
AND NOT EXISTS (SELECT 1 FROM TGFCAB 
                    WHERE TIPMOV='C' 
                    --Agora vou pesquisar a empresa da entrada intertendo as funções quem era cliente vira empresa
                    AND CODEMP=(SELECT CODEMP FROM TSIEMP WHERE CODEMP<500 AND CGC=(SELECT cgc_cpf FROM TGFPAR WHERE codparc=cab.codparc ))
                    -- Aquin quem é empresa vira cliente
                    AND codparc=(SELECT codparc FROM tgfpar WHERE CGC_CPF=(SELECT cgc FROM TSIEMP WHERE CODEMP=cab.CODEMP ))
                    --AND NUMNOTA=CAB.NUMNOTA AND SERIENOTA=CAB.SERIENOTA
                    AND CHAVENFE=CAB.CHAVENFE
                )
ORDER BY DTENTSAI DESC`;
}



function queryDetalhe(key) {
    return `Select nunota as key, nunota, (SELECT nomeparc FROM tgfpar WHERE codparc=cab.codparc) parceiro  FROM tgfcab cab WHERE nunota = ?`
}